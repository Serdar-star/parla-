import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

/* ═══════════════════════════════ USERS ═══════════════════════════════ */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull().unique(),
    username: text("username").notNull().unique(),
    fullName: text("full_name").notNull(),
    avatarUrl: text("avatar_url"),
    nativeLanguage: text("native_language").notNull().default("tr"),
    currentLanguage: text("current_language").notNull().default("en"),
    xp: integer("xp").notNull().default(0),
    level: integer("level").notNull().default(1),
    streak: integer("streak").notNull().default(0),
    longestStreak: integer("longest_streak").notNull().default(0),
    lastActivity: text("last_activity"),
    dailyGoal: integer("daily_goal").notNull().default(10),
    streakFreeze: integer("streak_freeze").notNull().default(1),
    coins: integer("coins").notNull().default(0),
    isPremium: boolean("is_premium").notNull().default(false),
    gamesPlayed: integer("games_played").notNull().default(0),
    bossKills: integer("boss_kills").notNull().default(0),
    passwordHash: text("password_hash").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({ emailIdx: index("users_email_idx").on(t.email) })
);

export const usersRelations = relations(users, ({ many }) => ({
  languages: many(userLanguages),
  lessons: many(userLessons),
  vocabulary: many(userVocabulary),
  achievements: many(userAchievements),
  activity: many(dailyActivity),
  leagues: many(leagues),
  conversations: many(aiConversations),
}));

/* ═══════════════════════════ USER_LANGUAGES ══════════════════════════ */
export const userLanguages = pgTable(
  "user_languages",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    languageCode: text("language_code").notNull(),
    cefrLevel: text("cefr_level").notNull().default("A1"),
    totalXp: integer("total_xp").notNull().default(0),
    wordsLearned: integer("words_learned").notNull().default(0),
    lessonsCompleted: integer("lessons_completed").notNull().default(0),
    currentUnit: integer("current_unit").notNull().default(1),
    currentLesson: integer("current_lesson").notNull().default(1),
    startedAt: timestamp("started_at").notNull().defaultNow(),
  },
  (t) => ({ userLangIdx: uniqueIndex("user_lang_idx").on(t.userId, t.languageCode) })
);

/* ═══════════════════════════════ LESSONS ═════════════════════════════ */
export const lessons = pgTable(
  "lessons",
  {
    id: serial("id").primaryKey(),
    languageCode: text("language_code").notNull().default("en"),
    cefrLevel: text("cefr_level").notNull().default("A1"),
    unitNumber: integer("unit_number").notNull(),
    lessonNumber: integer("lesson_number").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    type: text("type").notNull().default("ders"),
    xpReward: integer("xp_reward").notNull().default(20),
    estimatedMinutes: integer("estimated_minutes").notNull().default(7),
    content: jsonb("content").notNull().$type<unknown>(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({ lessonPathIdx: uniqueIndex("lesson_path_idx").on(t.languageCode, t.unitNumber, t.lessonNumber) })
);

export const lessonsRelations = relations(lessons, ({ many }) => ({
  userLessons: many(userLessons),
}));

/* ═══════════════════════════ USER_LESSONS ════════════════════════════ */
export const userLessons = pgTable(
  "user_lessons",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonId: integer("lesson_id")
      .notNull()
      .references(() => lessons.id, { onDelete: "cascade" }),
    completed: boolean("completed").notNull().default(false),
    score: integer("score").notNull().default(0),
    xpEarned: integer("xp_earned").notNull().default(0),
    mistakes: integer("mistakes").notNull().default(0),
    timeSpent: integer("time_spent").notNull().default(0),
    completedAt: timestamp("completed_at"),
  },
  (t) => ({ userLessonIdx: uniqueIndex("user_lesson_idx").on(t.userId, t.lessonId) })
);

export const userLessonsRelations = relations(userLessons, ({ one }) => ({
  lesson: one(lessons, { fields: [userLessons.lessonId], references: [lessons.id] }),
}));

/* ═══════════════════════════ VOCABULARY ══════════════════════════════ */
export const vocabulary = pgTable(
  "vocabulary",
  {
    id: serial("id").primaryKey(),
    languageCode: text("language_code").notNull().default("en"),
    word: text("word").notNull(),
    translation: text("translation").notNull(),
    pronunciation: text("pronunciation").notNull().default(""),
    exampleSentence: text("example_sentence").notNull().default(""),
    exampleTranslation: text("example_translation").notNull().default(""),
    imageEmoji: text("image_emoji").notNull().default("📖"),
    category: text("category").notNull().default("Genel"),
    cefrLevel: text("cefr_level").notNull().default("A1"),
    difficulty: integer("difficulty").notNull().default(1),
  },
  (t) => ({ wordIdx: uniqueIndex("vocab_word_idx").on(t.languageCode, t.word) })
);

/* ═══════════════════════════ USER_VOCABULARY ═════════════════════════ */
export const userVocabulary = pgTable(
  "user_vocabulary",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    vocabularyId: integer("vocabulary_id")
      .notNull()
      .references(() => vocabulary.id, { onDelete: "cascade" }),
    strength: integer("strength").notNull().default(0),
    timesReviewed: integer("times_reviewed").notNull().default(0),
    timesCorrect: integer("times_correct").notNull().default(0),
    nextReview: timestamp("next_review").notNull().defaultNow(),
    lastReviewed: timestamp("last_reviewed"),
  },
  (t) => ({ userVocabIdx: uniqueIndex("user_vocab_idx").on(t.userId, t.vocabularyId), reviewIdx: index("review_idx").on(t.userId, t.nextReview) })
);

/* ═══════════════════════════ ACHIEVEMENTS ════════════════════════════ */
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(),
  requirementType: text("requirement_type").notNull(),
  requirementValue: integer("requirement_value").notNull().default(1),
  xpReward: integer("xp_reward").notNull().default(0),
  coinReward: integer("coin_reward").notNull().default(0),
});

export const userAchievements = pgTable(
  "user_achievements",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    achievementId: integer("achievement_id")
      .notNull()
      .references(() => achievements.id, { onDelete: "cascade" }),
    earnedAt: timestamp("earned_at").notNull().defaultNow(),
  },
  (t) => ({ userAchIdx: uniqueIndex("user_ach_idx").on(t.userId, t.achievementId) })
);

export const userAchievementsRelations = relations(userAchievements, ({ one }) => ({
  achievement: one(achievements, { fields: [userAchievements.achievementId], references: [achievements.id] }),
}));

/* ═══════════════════════════ DAILY_ACTIVITY ══════════════════════════ */
export const dailyActivity = pgTable(
  "daily_activity",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    date: text("date").notNull(),
    xpEarned: integer("xp_earned").notNull().default(0),
    minutesSpent: integer("minutes_spent").notNull().default(0),
    lessonsCompleted: integer("lessons_completed").notNull().default(0),
    wordsReviewed: integer("words_reviewed").notNull().default(0),
  },
  (t) => ({ dayIdx: uniqueIndex("daily_activity_idx").on(t.userId, t.date) })
);

/* ═══════════════════════════════ LEAGUES ═════════════════════════════ */
export const leagues = pgTable(
  "leagues",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    leagueType: text("league_type").notNull().default("bronz"),
    weeklyXp: integer("weekly_xp").notNull().default(0),
    rank: integer("rank").notNull().default(0),
    weekStart: text("week_start").notNull(),
  },
  (t) => ({ weekIdx: uniqueIndex("league_week_idx").on(t.userId, t.weekStart), rankIdx: index("league_rank_idx").on(t.weekStart, t.weeklyXp) })
);

/* ═══════════════════════════ AI_CONVERSATIONS ════════════════════════ */
export const aiConversations = pgTable(
  "ai_conversations",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    languageCode: text("language_code").notNull().default("en"),
    role: text("role").notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({ convIdx: index("conv_user_idx").on(t.userId, t.createdAt) })
);

/* ═══════════════════════════ FRIENDSHIPS ═════════════════════════════ */
export const friendships = pgTable(
  "friendships",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    friendId: integer("friend_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("accepted"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({ friendIdx: uniqueIndex("friendship_idx").on(t.userId, t.friendId) })
);

/* ═══════════════════════════ DAILY TASKS ═════════════════════════════ */
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  icon: text("icon").notNull().default("📚"),
  xp: integer("xp").notNull().default(10),
});

export const userTasks = pgTable(
  "user_tasks",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    taskId: integer("task_id")
      .notNull()
      .references(() => tasks.id, { onDelete: "cascade" }),
    date: text("date").notNull(),
    completed: boolean("completed").notNull().default(false),
  },
  (t) => ({ userTaskIdx: uniqueIndex("user_task_idx").on(t.userId, t.taskId, t.date) })
);

/* ═══════════════════════════ FAVORİLER ═════════════════════════════ */
export const favorites = pgTable(
  "favorites",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    vocabularyId: integer("vocabulary_id")
      .notNull()
      .references(() => vocabulary.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({ favIdx: uniqueIndex("fav_idx").on(t.userId, t.vocabularyId) })
);

/* ═══════════════════════════ USER SETTINGS ═══════════════════════════ */
export const userSettings = pgTable(
  "user_settings",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" })
      .unique(),
    theme: text("theme").notNull().default("system"),
    soundEffects: boolean("sound_effects").notNull().default(true),
    micPermission: boolean("mic_permission").notNull().default(true),
    animations: boolean("animations").notNull().default(true),
    notifTime: text("notif_time").notNull().default("19:30"),
    notifLesson: boolean("notif_lesson").notNull().default(true),
    notifStreak: boolean("notif_streak").notNull().default(true),
    notifLeague: boolean("notif_league").notNull().default(false),
  }
);
