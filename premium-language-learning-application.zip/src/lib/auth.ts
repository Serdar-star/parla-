import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export const COOKIE_NAME = "parla-token";
const JWT_SECRET = process.env.JWT_SECRET || "parla-fallback-secret";

function secret() {
  return new TextEncoder().encode(JWT_SECRET);
}

export async function signToken(userId: number) {
  return new SignJWT({ sub: String(userId) })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret());
}

export async function verifyToken(token: string): Promise<number | null> {
  try {
    const { payload } = await jwtVerify(token, secret());
    return payload.sub ? Number(payload.sub) : null;
  } catch {
    return null;
  }
}

export async function setSessionCookie(userId: number) {
  const token = await signToken(userId);
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.set(COOKIE_NAME, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export type DbUser = typeof users.$inferSelect;

export function publicUser(u: DbUser) {
  return {
    id: u.id,
    email: u.email,
    username: u.username,
    fullName: u.fullName,
    avatarUrl: u.avatarUrl,
    nativeLanguage: u.nativeLanguage,
    currentLanguage: u.currentLanguage,
    xp: u.xp,
    level: u.level,
    streak: u.streak,
    longestStreak: u.longestStreak,
    dailyGoal: u.dailyGoal,
    streakFreeze: u.streakFreeze,
    coins: u.coins,
    isPremium: u.isPremium,
    gamesPlayed: u.gamesPlayed,
    bossKills: u.bossKills,
    createdAt: u.createdAt,
  };
}

export async function getCurrentUser(): Promise<DbUser | null> {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const id = await verifyToken(token);
  if (!id) return null;
  const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return rows[0] ?? null;
}

/** Auth gerektiren route'larda kullan — yoksa 401 hatası fırlatır. */
export async function requireUser(): Promise<DbUser> {
  const user = await getCurrentUser();
  if (!user) {
    throw new ApiError(401, "Oturum bulunamadı. Lütfen tekrar giriş yap.");
  }
  return user;
}

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string
  ) {
    super(message);
  }
}

export function handleApiError(err: unknown) {
  if (err instanceof ApiError) {
    return Response.json({ error: err.message }, { status: err.status });
  }
  console.error("API hatası:", err);
  return Response.json({ error: "Beklenmeyen bir hata oluştu." }, { status: 500 });
}
