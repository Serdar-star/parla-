"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Mascot } from "@/components/mascot";

export default function GroupLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/me", { cache: "no-store" })
      .then((res) => {
        if (cancelled) return;
        if (res.status === 401) router.replace("/login");
        else setChecked(true);
      })
      .catch(() => {
        if (!cancelled) router.replace("/login");
      });
    return () => {
      cancelled = true;
    };
  }, [router]);

  const isLessonPlayer = /^\/lessons\/[^/]+$/.test(pathname);

  if (!checked) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-bg">
        <Mascot mood="happy" size={130} />
        <p className="font-display text-lg font-semibold text-mut">Yükleniyor...</p>
      </div>
    );
  }

  if (isLessonPlayer) {
    return <div className="min-h-screen bg-bg">{children}</div>;
  }
  return <AppShell>{children}</AppShell>;
}
