import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Fredoka, Manrope } from "next/font/google";
import { ThemeProvider } from "next-themes";
import { ToastProvider } from "@/components/ui";
import { AppProvider } from "@/stores/app";
import "./globals.css";

const fredoka = Fredoka({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-fredoka",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Parla — Dil Öğrenmenin En Güzel Hâli",
  description:
    "AI öğretmen, boss savaşları, ligler ve bilim destekli tekrar sistemiyle yeni bir dili oyun oynar gibi öğren. 24 dil, tek uygulama.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "Parla" },
  icons: { icon: "/icons/icon.svg" },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f7f8f3" },
    { media: "(prefers-color-scheme: dark)", color: "#0b100d" },
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr" suppressHydrationWarning className={`${fredoka.variable} ${manrope.variable}`}>
      <body className="min-h-screen bg-bg font-body text-ink antialiased">
        <ThemeProvider attribute="class" defaultTheme="light">
          <AppProvider>
            <ToastProvider>{children}</ToastProvider>
          </AppProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
